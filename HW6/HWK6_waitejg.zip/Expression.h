#ifndef EXPRESSION_H
#define EXPRESSION_H

class Expression{
	virtual std::string evaluate();
	virtual void print(); 
};

#endif