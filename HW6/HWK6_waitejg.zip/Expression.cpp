/*
Name:  Joseph Waite, Joel Straatman
MacID: waitejg, straatjc,
Student Number:  001403712, 001314676,
Description: scientific calculator with bonus
*/
#include <string>

class Expression{
	virtual std::string evaluate();
	virtual void print(); 
};

